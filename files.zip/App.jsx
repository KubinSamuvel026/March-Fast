import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar.jsx'
import HomePage from './pages/HomePage.jsx'
import ProductsPage from './pages/ProductsPage.jsx'
import ProductDetailPage from './pages/ProductDetailPage.jsx'
import CartPage from './pages/CartPage.jsx'
import WishlistPage from './pages/WishlistPage.jsx'
import CheckoutPage from './pages/CheckoutPage.jsx'
import OrderSuccessPage from './pages/OrderSuccessPage.jsx'

export default function App() {
  return (
    <div className="page-wrapper">
      <Navbar />
      <Routes>
        <Route path="/"               element={<HomePage />} />
        <Route path="/products"       element={<ProductsPage />} />
        <Route path="/product/:id"    element={<ProductDetailPage />} />
        <Route path="/cart"           element={<CartPage />} />
        <Route path="/wishlist"       element={<WishlistPage />} />
        <Route path="/checkout"       element={<CheckoutPage />} />
        <Route path="/order-success"  element={<OrderSuccessPage />} />
      </Routes>
    </div>
  )
}
